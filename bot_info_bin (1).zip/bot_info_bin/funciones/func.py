from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import requests



# VARIABLES
icon = "<a href='https://www.example.com'>メ</a>"
inf = "<b><a href='https://www.example.com'>•</a></b>"



# REQUESTS AN API FROM ONYX APIS XD
def req_api(BIN):
    api_url = f"https://onyxbinlookup.onrender.com/bin/{BIN}"
    response = requests.get(api_url)
    
    if response.status_code == 200:
        try:
            data = response.json()
            if data["Success"]:
                api = data["API Result"]

                BANK = api.get("BANK")
                BIN = api.get("BIN")
                BRAND = api.get("BRAND")
                COUNTRY = api.get("COUNTRY")
                CODE_MJ = api.get("CODE_MOGI")
                LEVEL = api.get("LEVEL")
                TYPE = api.get("TYPE")
                WEB = api.get("WEB_BANK")
                PHONE = api.get("NUMBER_BANK")

                return BANK, BIN, BRAND, COUNTRY, CODE_MJ, LEVEL, TYPE, WEB, PHONE
            else:
                print(f"error      {response.status_code}")
                return None     
        except Exception as e:
            print(f"error       {e}")
            return None



# BUTTONS 
botones = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton("[🌥️] 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿", url="https://t.me/VyPradaX"), 
            InlineKeyboardButton("[🌩️] 𝗣𝗿𝗼𝘆𝗲𝗰𝘁", url="https://t.me/ProyectsVyPrada")
        ]
    ]
)